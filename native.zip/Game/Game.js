
//Called when application is started.
function OnStart()
{
    //Lock screen orientation to Landscape and
    //stop screen turning off while playing.
    app.SetOrientation( "Landscape" );
    app.PreventScreenLock( true );
    
    //Create the main layout
    lay = app.CreateLayout( "Linear", "Vertical,FillXY,VCenter" );
    
    //Create game view and load our game.
    gam = app.CreateGameView( 1, 1 );
    gam.SetFile( "Bounce.js" );
    lay.AddChild( gam );
    
    app.AddLayout( lay );
}
