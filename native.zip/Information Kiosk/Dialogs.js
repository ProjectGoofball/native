
//These dialogs allow user input without taking the input focus. When a control
//takes the input focus, it will popup the soft keyboard and cause the tablet's 
//navigation controls to accessible (which is undesirable in a kiosk mode app)

//Show a pin dialog.
function ShowPinDialog( callback )
{
    new PinDialog( callback );
}

//Generic pin code input dialog class (does not take focus).
function PinDialog( callback )
{
    //Add a button to a given layout.
    this.AddButton = function( lay, name )
    {
    	var btn = app.CreateButton( name, 0.2, 0.1 );
    	btn.SetTextSize( 18 );
    	btn.SetTextColor( "#666666" );
    	btn.SetOnTouch( this.btns_OnTouch );
    	lay.AddChild( btn );
    }
    
    //Called when user presses number buttons.
    this.btns_OnTouch = function()
    {
    	app.Vibrate( "0,100" );
    	
    	//Get button text.
    	btn = app.GetLastButton();
    	var txt = btn.GetText();
    	 	
    	//Handle buttons.
    	if( txt=="C" ) sum = "";
    	else sum += txt;
    	
    	//Update display.
    	txtSum.SetText( sum );
    }
    
    this.OnCancel = function() { 
        dlgPin.Dismiss(); 
    }
    
    this.OnOk = function() { 
        dlgPin.Dismiss(); 
        if( callback ) callback( txtSum.GetText() );
    }
    
    //Private vars.
    var sum = "";
    
    //Get orientation.
    var orient = app.GetOrientation();
    var textWidth = (orient=="Portrait" ? 0.8 : 0.5 );
    var btnWidth =  (orient=="Portrait" ? 0.4 : 0.25 );

    //Create dialog window.
    var dlgPin = app.CreateDialog( null, "nofocus" );
    var layTxtDlg = app.CreateLayout( "linear", "vertical,fillxy" );
    layTxtDlg.SetPadding( 0.04, 0.02, 0.04, 0 );

    //Create array to hold number buttons.
	var keys = [ 7,8,9, 4,5,6, 1,2,3, 0,"#","C" ];
	
	//Create text control for displaying sum.
	var txtSum = app.CreateText( "", 0.6 );
	txtSum.SetTextSize( 32 );
	txtSum.SetBackColor( "#11000000" );
	txtSum.SetMargins( 0, 0.02, 0, 0.03 );
	layTxtDlg.AddChild( txtSum );
	
	//Create first row of buttons.
	var lay1st = app.CreateLayout( "linear", "Horizontal" );	
	for( i=0; i<3; i++ ) this.AddButton( lay1st, keys[i] );
	layTxtDlg.AddChild( lay1st );
	
	//Create second row of buttons.
	var lay2nd = app.CreateLayout( "linear", "Horizontal" );	
	for( i=3; i<6; i++ ) this.AddButton( lay2nd, keys[i] );
	layTxtDlg.AddChild( lay2nd );
	
	//Create third row of buttons.
	var lay3rd = app.CreateLayout( "linear", "Horizontal" );	
	for( i=6; i<9; i++ ) this.AddButton( lay3rd, keys[i] );
	layTxtDlg.AddChild( lay3rd );
	
	//Create fourth row of buttons.
	var lay4th = app.CreateLayout( "linear", "Horizontal" );	
	for( i=9; i<12; i++ ) this.AddButton( lay4th, keys[i] );
	layTxtDlg.AddChild( lay4th );
    
    var layTxtDlg2 = app.CreateLayout( "linear", "horizontal,fillxy,center" );
    layTxtDlg2.SetMargins( 0, 0.02, 0, 0.01 ); 
   
    var btnTxtCancel = app.CreateButton( "Cancel", btnWidth, 0.1, "" );
	btnTxtCancel.SetTextSize( 16 );
	btnTxtCancel.SetTextColor( "#666666" );
    btnTxtCancel.SetOnTouch( this.OnCancel );
    layTxtDlg2.AddChild( btnTxtCancel );
    
    var btnTxtOK = app.CreateButton( "OK", btnWidth, 0.1, "" );
    btnTxtOK.SetTextSize( 16 );
	btnTxtOK.SetTextColor( "#666666" );
    btnTxtOK.SetOnTouch( this.OnOk );
    layTxtDlg2.AddChild( btnTxtOK );
    
    layTxtDlg.AddChild( layTxtDlg2 );

    //Add dialog layout and show dialog.
    dlgPin.AddLayout( layTxtDlg );
    dlgPin.Show();
    
    //Start timer to auto-hide dialog.
    setTimeout( function(){ dlgPin.Dismiss() }, 7000 );
}


