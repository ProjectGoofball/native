/*
  Kiosk Template
  ==============
  
  This template provides a good framework for building tablet based touch screen
  'Kiosk' style apps which are suitable for use in schools, museums, home 
  automation and industrial machine control scenarios where you don't want the
  user to 'escape' from the app and get at the Android menus.
  
  The code is designed to run on Android based tablets and industrial panel PC 
  hardware which still tend to use the older KitKat,Lollipop,Nougat versions of
  Android.
  
  This template is designed to work on non-rooted devices with software 
  navigation buttons so if you want to use a device with hardware buttons, you 
  will need to physically block those buttons to prevent the user from escaping 
  the app. 
  
  Setting the g_autoBoot global to true will cause this app to be automatically 
  started up when the tablet is started. You will also need to disable the lock 
  screen in the Android/Security settings for this to work properly.
  
  To escape the app, either enter the secret 3 finger touch (see Admin.js) or
  press the power button for a few seconds, then press the back button.
  
  The home video used in this template is streamed via the internet to save
  space, but it would be better to download your videos and store them on the 
  internal sdcard of the tablet to improve performance and reliability.
 
  Tested (and affordable) tablets include:-
  - ASUS Zenpad Z300M (recommended)
  - ASUS Zenpad Z380M (recommended)
  - AllDoCube T12 (gprs available)
  - Fusion5 10.6 Inch Tablet PC
*/

//Load external scripts.
app.LoadScript( "Dialogs.js" );
app.LoadScript( "Comms.js" );
app.LoadScript( "Home.js" );
app.LoadScript( "Select.js" );
app.LoadScript( "Info.js" );
app.LoadScript( "Admin.js" );

//Init some global variables.
var g_appPath = "/sdcard/Kiosk";    //Data folder.
var g_curPage = null;               //Current page object.
var g_tmTimeout = null;             //Timeout timer.
var g_touchTimeout = 30000;         //Time before reverting back to home page.
var g_debug = false;                //Enable debug mode.
var g_autoBoot = false;             //Auto start this app on boot up.

//Called when application is started.
function OnStart()
{    
    //Lock screen orientation to Landscape.
    app.SetOrientation( "Landscape" );
    
    //Set full screen game mode.
    app.SetScreenMode( "Game" );
    
    //Stop user getting to navigation menus.
    //(Use 'White' or 'Black' option to block out menus with solid color)
    app.SetKioskMode( "Status,Nav", true );
    
    //Create a theme for all controls.
    CreateTheme();
    
    //Create folder on internal sdcard to store settings.
    app.MakeFolder( g_appPath );
    
    //Read settings from sdcard (or apk if not found on sdcard).
    //(This file could also be downloaded from a remote web server if required)
    var file = g_appPath + "/settings.json";
    if( app.FileExists(file) ) g_sets = JSON.parse(app.ReadFile(file));
    else g_sets = JSON.parse( app.ReadFile("settings.json") );
            
	//Create the main app layout with objects vertically centered.
	g_layMain = app.CreateLayout( "Linear", "VCenter,FillXY" );
	g_layMain.SetBackground( "Img/splash.png", "repeat" );
	
	//Create transparent top layer for warnings and hints etc.
	g_layOver = app.CreateLayout( "Absolute", "FillXY,TouchThrough" ); 
	
	//Create main controls and menus.
	CreatePageContainer();
	CreateOverlay();
	
	//Create page objects.
	g_home = new Home( layContent );
	g_select = new Select( layContent);
	g_info = new Info( layContent);
	g_admin = new Admin( layContent);
	
	//Create communication object.
	g_comms = new Comms();
	
	//Add main layout and drawer to app.	
	app.AddLayout( g_layMain );
	app.AddLayout( g_layOver );
		
	//Show home page.
	g_home.Load();
	ChangePage( g_home );
	
	//Hide splash image after shortly after startup.
	setTimeout( function(){g_layMain.SetBackColor("black")}, 3000 );
	
	//Start this app on tablet boot up (if required).
	//(SetAutoWifi and SetAutoStart have no effect in APKs)
    app.SetAutoBoot( g_autoBoot ? "app" : null ); 
    app.SetAutoWifi( g_autoBoot );    
    app.SetAutoStart( g_autoBoot ? app.GetAppName() : null ); 
}

//Create area for showing page content.
function CreatePageContainer()
{
    layContent = app.CreateLayout( "Frame", "VCenter,FillXY" );
    layContent.SetSize( 1, 1 );
    g_layMain.AddChild( layContent );
}

//Create overlay controls such as warning triangle.
function CreateOverlay()
{
    //Create warning triangle.
    g_txtWarn = app.CreateText( "[fa-exclamation-triangle]",-1,-1,"FontAwesome" ); 
    g_txtWarn.SetPosition( 0.955, 0.01 );
    g_txtWarn.SetTextSize( 24 );
    g_txtWarn.SetTextColor( "#ffcc00" );
    g_txtWarn.Hide();
    g_layOver.AddChild( g_txtWarn );
}
   
//Swap the page content.
function ChangePage( page )
{ 
    //Guard against rapid screen tapping.
    g_changing = true;
    setTimeout( function(){ g_changing=false; }, 500 );
    
    //Fade out current content.
    if( g_home.IsVisible() ) g_home.Hide();
    if( g_select.IsVisible() ) g_select.Hide();
    if( g_info.IsVisible() ) g_info.Hide();
    if( g_admin.IsVisible() ) g_admin.Hide();
    
    //Fade in new content and set current page
    page.Show();
    g_curPage = page;
    
    //Reset touch timeout.
    ResetTimeout();
}
    	
//Reset the screen timeout timer.
function ResetTimeout()
{
    clearTimeout( g_tmTimeout );
	if( !g_debug ) g_tmTimeout = setTimeout( OnTimeout, g_touchTimeout );
}

//Called when user has not touched screen for a while.
function OnTimeout()
{
    if( !g_home.IsVisible() )
    {
        app.SetScreenMode( "Game" );
        g_home.Load();
        ChangePage( g_home );
    }
}

//Create a theme for all controls and dialogs.
function CreateTheme()
{
    theme = app.CreateTheme( "Light" );
    theme.AdjustColor( 35, 0, -10 );
    theme.SetBackColor( "#ffffffff" );
    theme.SetBtnTextColor( "#000000" );
    theme.SetButtonOptions( "custom" );
    theme.SetButtonStyle( "#fafafa","#fafafa",5,"#999999",0,1,"#ff9000" );
    theme.SetCheckBoxOptions( "dark" );
    theme.SetTextEditOptions( "underline" );
    theme.SetDialogColor( "#ffffffff" );
    theme.SetDialogBtnColor( "#ffeeeeee" );
    theme.SetDialogBtnTxtColor( "#ff666666" );
    theme.SetTitleHeight( 42 );
    theme.SetTitleColor( "#ff888888" ); 
    theme.SetTitleDividerColor( "#ff0099CC" );
    theme.SetTextColor( "#000000" );
    app.SetTheme( theme );
}

