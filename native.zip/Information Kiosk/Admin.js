/*
  Secret Admin/Settings page
  
  This page can be reached by holding 3 fingers down on background of the 
  main selection page for more than 3 seconds.  Enter 4242 at the pin prompt.
*/

"use strict"

//Create an Admin class.
function Admin( layContent )
{
    var self = this;
    
    //Set and get page visibility.
    this.Show = function() { lay.Animate("FadeIn", null, 300 ); }
    this.Hide = function() { lay.Animate( "FadeOut" ); }
    this.IsVisible = function() {  return lay.IsVisible(); }
   
    //Load page data.
    this.Load = function()
    {
        //Load settings.
        var file = g_appPath + "/settings.json";
        if( app.FileExists(file) ) g_sets = JSON.parse(app.ReadFile(file));
        else g_sets = JSON.parse( app.ReadFile("settings.json") );
        
        //Update controls.
        edtSaver.SetText( g_sets.screensaver );
        
        //Disable kiosk mode and timeout timer.
        app.SetKioskMode( "Status,Nav", false );
        clearTimeout( g_tmTimeout );
    }
    
    //Handle Done button.
    this.btnDone_OnTouch = function()
    {
        //Get values from controls.
        g_sets.screensaver = edtSaver.GetText();
        
        //Save settings to internal sdcard.
        var file = g_appPath + "/settings.json";
        app.WriteFile( file, JSON.stringify(g_sets) );
        
        //Go back to home page.
        g_home.Load();
        ChangePage( g_home );
        
        //Re-enable kiosk mode and timeout timer.
        app.SetScreenMode( "Game" );
        app.SetKioskMode( "Status,Nav", true );
        ResetTimeout();
    }
    
    //Create layout (hidden at first).
    var lay = app.CreateLayout( "Linear", "FillXY,VCenter" ); 
    lay.SetBackColor( "white" );
    lay.Hide();
    layContent.AddChild( lay );
    
    //Edit box for home screen (screen saver) video path.
    var edtSaver = app.CreateTextEdit( "", 0.7 );
    edtSaver.SetMargins( 0,8,0,16, "dp" );
    lay.AddChild( edtSaver );
    
    //Todo: Add more settings controls here
    //***
    
    //Create horizonal layout for wifi and bt buttons.
    var layHoriz = app.CreateLayout( "Linear", "Horizontal,VCenter" );
    layHoriz.SetMargins( 0,0,0,16, "dp" );
    lay.AddChild( layHoriz );
        
    //Create Wifi setup button.
    var btnWifi = app.CreateButton( "[fa-wifi]", 0.16,0.1, "FontAwesome" );
    btnWifi.SetMargins( 8,0,8,0, "dp" );
    btnWifi.SetSize( 60, 60, "dp" );
    btnWifi.SetTextSize( 15 );
    btnWifi.SetTextColor( "#666666" );
    btnWifi.SetOnTouch( function(){app.SendIntent(null,null,"android.settings.WIFI_SETTINGS" )} );
    layHoriz.AddChild( btnWifi );
    
    //Create setup Bluetooth button.
    var btnBT = app.CreateButton( "[fa-bluetooth-b]", 0.16,0.1, "FontAwesome" );
    btnBT.SetMargins( 8,0,8,0, "dp" );
    btnBT.SetSize( 60, 60, "dp" );
    btnBT.SetTextSize( 15 );
    btnBT.SetTextColor( "#666666" );
    btnBT.SetOnTouch( function(){app.SendIntent(null,null,"android.settings.BLUETOOTH_SETTINGS" )} );
    layHoriz.AddChild( btnBT );
        
    //Create Done button.
    var btnDone = app.CreateButton( "Done", 0.16, 0.1 );
    btnDone.SetMargins( 0, 0.04, 0, 0 );
    btnDone.SetTextSize( 12 );
    btnDone.SetOnTouch( this.btnDone_OnTouch );
    lay.AddChild( btnDone );
}


