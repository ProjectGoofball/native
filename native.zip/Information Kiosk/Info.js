"use strict"

//Create a Info class.
function Info( layContent )
{
    var self = this;
    var layInfo = null;
    
    //Set and get page visibility.
    this.Show = function() { lay.Animate("FadeIn", null, 250 ); }
    this.Hide = function() { lay.Animate( "FadeOut" ); }
    this.IsVisible = function() {  return lay.IsVisible(); }
   
    //Load page.
    this.Load = function( name )
    {
        //Destroy any previous layout (to free memory).
        if( layInfo ) lay.DestroyChild( layInfo );
        
        //Create new info layout.
        layInfo = app.CreateLayout( "Linear", "Horizontal,FillXY,VCenter" ); 
        layInfo.SetMargins( 0,0,0,0.05 );
        lay.AddChild( layInfo );
        
        //Create image.
        var imgCrew = app.CreateImage( "Img/"+name+"-Crew.jpg", 0.5 );
        imgCrew.SetMargins( 0.03,0,0.03,0 );
        imgCrew.AdjustColor( 0, 10, 20, 0 ); //<-improves color on cheap tablets
        layInfo.AddChild( imgCrew );
        
        //Create text area.
        var s = app.ReadFile( "Misc/"+name+".txt" );
        var txt = app.CreateText( s, 0.4, -1, "MultiLine,Left,Html" );
        txt.SetTextSize( 18 );
        layInfo.AddChild( txt );
    }
    
    //Handle back button.
    this.txtBack_OnTouch = function( ev )
    {
        if( ev.action=="Down" ) 
            this.SetScale( 0.9, 0.9 );
            
        else if( ev.action=="Up" ) 
        { 
            this.SetScale( 1, 1 );
            if( g_changing ) return;
            ChangePage( g_select );
        }
    }
    
    //Create layout (hidden at first).
    var lay = app.CreateLayout( "Linear", "FillXY,VCenter" ); 
    lay.SetBackColor( "white" );
    lay.Hide();
    layContent.AddChild( lay );
    
    //Add back button.
    var txtBack = app.CreateText( "[fa-arrow-circle-left]", 0.16,-1,"FontAwesome" );
    txtBack.SetMargins( 0,0.02,0.44,0 );
    txtBack.SetTextSize( "66" );
    txtBack.SetTextColor( "#aaaaaa" );
    txtBack.SetOnTouch( this.txtBack_OnTouch );
    lay.AddChild( txtBack );
}


