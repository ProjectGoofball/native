
//Communcation class 
//(could be based on XmlHttpRequest, WebSocket, Bluetooth, USB etc).
//
//Note: You can delete this file if you are not connecting to external devices.

"use strict"

function Comms()
{
    var self = this;
    
    //Check if we are connected.
    this.IsConnected = function() 
    { 
        //Todo: Check state of connection here.
        return false; 
    }
    
    //Send a command/request to remote device/server.
    this.Send = function( cmd )
    {
        console.log( cmd + "\n" );
    }
    
    //Check connection is alive
    this.CheckConnect = function()
    {
        console.log( "Connecting..." );
        
        if( !self.IsConnected() )
        {
            //Todo: Attempt connection here.
            //***
        }
    }
    
    //Called after we are connected.
    //(Set this method as your connection callback)
    this.OnConnect = function( ok )
    {
        console.log( "Connected" ); 
       
        //Todo: Do stuff here.
        //***
    }
    
    //Called when we receive data
    //(Set this method as your receive callback)
    this.OnReceive = function( data )
    {
        console.log( data );
        
        //Todo: Handle data here.
    }
    
    //Todo: Create Net/BT/USB connection object.
    //***
	
	//Attempt connection with remote device/server.
	this.CheckConnect();
	setInterval( this.CheckConnect, g_debug?30000:7000 );
}

