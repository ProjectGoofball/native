"use strict"

//Create a Select class.
function Select( layContent )
{
    var self = this;
    var adminTimer = null;
    
    //Set and get page visibility.
    this.Show = function() { lay.Animate("FadeIn", null, 300 ); }
    this.Hide = function() { lay.Animate( "FadeOut" ); }
    this.IsVisible = function() {  return lay.IsVisible(); }
   
    //Load page.
    this.Load = function()
    {
        //Todo: Optionally add code to alter page contents.
    }
    
    //Handle image touches by user.
    this.img_OnTouch = function( ev )
    {
        if( ev.action=="Down" ) 
            this.Scale( 0.9, 0.9 );
            
        else if( ev.action=="Up" ) 
        { 
            this.Scale( 1, 1 );
            
            if( g_changing ) return;
            g_info.Load( this.name );
            ChangePage( g_info );
        }
    }
    
    //Check the admin pin is correct.
    this.CheckPin = function( pin )
    {
        if( pin=="4242" ) 
        {
            g_admin.Load();
            ChangePage( g_admin );
        }
    }
    
    //Check for the secret admin touch combo.
    //(Hold 3 fingers on background for more than 3 seconds)
    this.lay_SetOnTouchMove = function( ev )
    {
        if( ev.count==3 ) 
        {
            if( !adminTimer ) 
                adminTimer = setTimeout( function(){ShowPinDialog(self.CheckPin)}, 2000 );
        }
        else 
        { 
            clearTimeout( adminTimer );
            adminTimer = null;
        }
    }
    
    //Create layout (hidden at first).
    var lay = app.CreateLayout( "Linear", "FillXY,VCenter" ); 
    lay.SetBackColor( "white" );
    lay.SetOnTouchMove( this.lay_SetOnTouchMove );
    lay.Hide();
    layContent.AddChild( lay );
    
    //Create upper and lower image layouts.
    var layTop = app.CreateLayout( "Linear", "Horizontal,FillX,VCenter" );
    lay.AddChild( layTop );
    var layBottom = app.CreateLayout( "Linear", "Horizontal,FillX,VCenter" );
    lay.AddChild( layBottom );
    
    //Add images.
    var img = app.CreateImage( "Img/ISS-17-Patch.png", 0.3 );
    img.SetMargins( 0.04,0,0.04,0 );
    img.AdjustColor( 0, 10, 20, 0 ); //<-improves color on some tablets
    img.SetOnTouch( this.img_OnTouch );
    img.name = "ISS-17";
    layTop.AddChild( img );
    
    var img = app.CreateImage( "Img/ISS-46-Patch.png", 0.3 );
    img.SetMargins( 0.04,0,0.04,0 );
    img.AdjustColor( 0, 10, 20, 0 ); 
    img.SetOnTouch( this.img_OnTouch );
    img.name = "ISS-46";
    layTop.AddChild( img );
}


