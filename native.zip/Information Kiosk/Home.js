"use strict"

//Create a Home page class.
function Home( layContent )
{
    var self = this;
    var touched = false;

    //Set and get page visibility.
    this.Show = function() { lay.Animate("FadeIn", null, 2000 ); }
    this.Hide = function() { lay.Animate( "FadeOut" ); }
    this.IsVisible = function() {  return lay.IsVisible(); }
	
	//Load page content.
    this.Load = function()
    {
        //Here we streaming an online video, but you could simply copy the
        //video to the local sdcard and play it from there instead.
        player.SetFile( g_sets.screensaver );
        touched = false;
    }
    
    //Called when file is ready to play.
    this.player_OnReady = function()
    {
        player.SetBackColor( "#00000000" );
        if( !touched ) player.Play();
    }
    
    //Called when layout/video is touched.
    this.lay_OnTouchDown = function()
    {
        touched = true;
        
        //Stop video and hide hand overlay.
        player.Stop();
        imgHand.Hide();
        
        //Load user selection page.
        g_select.Load();
        ChangePage( g_select );
    }
    
    //Create layout (hidden at first).
    var lay = app.CreateLayout( "Linear", "FillXY,VCenter" ); 
    lay.SetOnTouchDown( this.lay_OnTouchDown );
    lay.Hide();
    layContent.AddChild( lay );
        
	//Create video view.
	var player = app.CreateVideoView( 1, 1 );
	player.SetBackColor( "black" );
	player.SetOnReady( this.player_OnReady );
	player.SetOnError( function(){ app.ShowPopup("Video Error!") } );
	player.SetOnComplete( function(){ player.Stop(); player.Play() } );
	lay.AddChild( player );
	
	//Add hand touch image.
	var imgHand = app.CreateImage( "Img/hand.png", 0.1,-1, "anti-alias" );
	imgHand.SetPosition( 0.87,0.7 );
	g_layOver.AddChild( imgHand );
}


