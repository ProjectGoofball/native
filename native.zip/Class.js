
class MyClass
{
	constructor()
	{
		//Properties
		this.name = "Fred"
		this.age = 77
	}
	
	//---- METHODS ----
	
	Test()
	{
	   //Note: we use an arrow function so 'this' works inside callbacks.
		app.TextToSpeech( "Hello " + this.name, 1,1, ()=>{this.OnSpeechDone()} )
	}
	
	//---- CALLBACKS ----
	
	OnSpeechDone()
	{
		app.ShowPopup( "Your age is " + this.age )
	}
}
